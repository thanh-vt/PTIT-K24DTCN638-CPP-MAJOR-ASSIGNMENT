#include <iomanip>
#include <ios>
#include <iostream>
#include <sstream>
#include <regex>
#include "util.h"
#include "b_35.h"

int main() {
    using namespace std;
    cerr << "b_35: DANH SÁCH SINH VIÊN - 2" << endl;
    string line;
    cerr << "Nhập số sinh viên N:" << endl;
    bool is_valid = false;
    int N = 0;
    do {
        getline(cin, line);
        try {
            N = parse_int(line);
        } catch (const exception &e) {
            cerr << e.what() << endl;
            continue;
        }
        if (N < 1) {
            cerr << "T phải >= 1" << endl;
            continue;
        }
        if (N > 50) {
            cerr << "T phải <= 50" << endl;
            continue;
        }
        is_valid = true;
    } while (!is_valid);
    vector<Student > S_inputs;
    for (int i = 0; i < N; i++) {
        cerr << "Nhập họ tên của sinh viên " << i + 1 << ":" << endl;
        string fullname;
        do {
            try {
                is_valid = false;
                getline(cin, line);
                fullname = normalize_and_validate_name(line, 30);
            } catch (const exception &e) {
                cerr << e.what() << endl;
                continue;
            }
            is_valid = true;
        } while (!is_valid);
        cerr << "Nhập lớp của sinh viên " << i + 1 << ":" << endl;
        string clazz;
        do {
            try {
                is_valid = false;
                getline(cin, line);
                clazz = validate_ptit_clazz(line);
            } catch (const exception &e) {
                cerr << e.what() << endl;
                continue;
            }
            is_valid = true;
        } while (!is_valid);
        cerr << "Nhập ngày sinh của sinh viên " << i + 1 << ":" << endl;
        tm date_of_birth{};
        do {
            try {
                is_valid = false;
                getline(cin, line);
                date_of_birth = parse_date(line);
            } catch (const exception &e) {
                cerr << e.what() << endl;
                continue;
            }
            is_valid = true;
        } while (!is_valid);
        float gpaMark = 0;
        cerr << "Nhập điểm GPA của sinh viên " << i + 1 << ":" << endl;
        do {
            try {
                is_valid = false;
                getline(cin, line);
                gpaMark = parse_float(line);
                if (gpaMark < 0) {
                    cerr << "Điểm GPA phải >= 0" << endl;
                    continue;
                }
                if (gpaMark > 4) {
                    cerr << "Điểm GPA phải <= 4" << endl;
                    continue;
                }
                static regex float_regex(R"(^\s*(\d+)(?:\.(\d*?))?\s*$)");
                smatch match;
                if (regex_match(line, match, float_regex)) {
                    string decimal_part = match[2].str();
                    if (decimal_part.size() > 2) {
                        cerr << "Điểm GPA có nhiều nhất 2 chữ số sau dấu phẩy" << endl;
                        continue;
                    }
                }

            } catch (const exception &e) {
                cerr << e.what() << endl;
                continue;
            }
            is_valid = true;
        } while (!is_valid);
        const Student student(fullname, clazz, date_of_birth, gpaMark);
        S_inputs.push_back(student);
    }
    cerr << "Kết quả:" << endl;
    for (int i = 0; i < N; i++) {
        const Student& student = S_inputs[i];
        cout << student << endl;
    }
    return 0;
}

Student::Student(std::string fullname, std::string clazz, const std::tm &date_of_birth, const float gpa_mark)
        : fullname(std::move(fullname)),
          clazz(std::move(clazz)),
          dateOfBirth(date_of_birth),
          gpaMark(gpa_mark) {
    using namespace std;
    ++counter;
    std::ostringstream oss;
    oss << "B20DCCN" << setw(3) << setfill('0') << counter;
    this->code = oss.str();
}

std::ostream &operator<<(std::ostream &os, const Student &student) {
    using namespace std;
    os
            << student.code << " "
            << student.fullname << " "
            << print_date(student.dateOfBirth) << " "
            << student.clazz << " "
            << fixed << setprecision(2) << student.gpaMark;
    return os;
}

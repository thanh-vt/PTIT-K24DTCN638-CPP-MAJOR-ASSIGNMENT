#ifndef B_33_H
#define B_33_H

std::vector<int> sort_alternating(std::vector<int>& a);

#endif //B_33_H

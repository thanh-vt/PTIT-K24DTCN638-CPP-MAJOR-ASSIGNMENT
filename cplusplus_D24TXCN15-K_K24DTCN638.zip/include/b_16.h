#ifndef B_16_H
#define B_16_H
#include <string>

std::string find_min(int m, int s);

std::string find_max(int m, int s);

#endif //B_16_H

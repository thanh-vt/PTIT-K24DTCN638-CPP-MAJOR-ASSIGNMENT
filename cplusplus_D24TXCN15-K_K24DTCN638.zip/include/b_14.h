#ifndef B_14_H
#define B_14_H

void print_unique_element(const std::vector<int> &A);

#endif //B_14_H

#ifndef B_02_H
#define B_02_H

/**
 * Chuyển đổi ký tự in hoa và in thường hoặc ngược lại
 *
 * @param c Ký tự đầu vào
 * @return Ký tự đã được chuyển đổi
 */
char convert_char(char c);

#endif //B_02_H

#ifndef B_47_H
#define B_47_H
#include <string>

bool is_binary(const std::string& str);

int max_deleted_length(const std::string& s);

#endif //B_47_H

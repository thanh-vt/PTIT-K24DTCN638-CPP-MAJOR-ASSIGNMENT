#ifndef B_05_H
#define B_05_H

bool ends_with(int value, int suffix);

#endif //B_05_H

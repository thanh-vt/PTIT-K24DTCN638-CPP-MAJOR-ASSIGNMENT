#ifndef B_09_H
#define B_09_H

int find_min_diff(std::vector<int> A);

#endif //B_09_H

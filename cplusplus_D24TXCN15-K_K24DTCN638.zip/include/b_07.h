#ifndef B_07_H
#define B_07_H

/**
 * In các ước số nguyên tố
 *
 * @param n số nguyên dương đầu vào
 */
void print_factorization(long n);

#endif //B_07_H

#ifndef B_28_H
#define B_28_H

int find_largest_smaller_number(int n);

#endif //B_28_H

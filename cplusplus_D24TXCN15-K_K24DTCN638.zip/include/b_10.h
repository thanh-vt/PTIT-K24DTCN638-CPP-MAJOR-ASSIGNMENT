#ifndef B_10_H
#define B_10_H

size_t find_smallest_missing_positive(const std::vector<int>& arr);

#endif //B_10_H

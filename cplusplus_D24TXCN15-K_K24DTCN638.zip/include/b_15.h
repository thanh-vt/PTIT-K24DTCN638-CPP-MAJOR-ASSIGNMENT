#ifndef B_15_H
#define B_15_H

int count_array_duplicated_elements(const std::vector<int> &A);

#endif //B_15_H

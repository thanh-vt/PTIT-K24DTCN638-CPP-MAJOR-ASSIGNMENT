#ifndef B_19_H
#define B_19_H
#include <set>

std::set<int> sort_digits_array(const std::vector<long>& A);

#endif //B_19_H

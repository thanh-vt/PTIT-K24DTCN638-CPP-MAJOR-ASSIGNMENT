#ifndef B_18_H
#define B_18_H

bool is_vowel(char c);

std::string remove_vowels(const std::string &S);

#endif //B_18_H

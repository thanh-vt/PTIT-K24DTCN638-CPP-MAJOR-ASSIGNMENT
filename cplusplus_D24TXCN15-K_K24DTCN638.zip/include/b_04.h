#ifndef B_04_H
#define B_04_H

/**
 * Cân bằng chẵn lẻ
 *
 * @param n Số nguyên dương đầu vào
 * @return trong n số chữ số chẵn có bằng số chữ số lẻ hay không
 */
bool has_equal_odd_even_digits(int n);

#endif //B_04_H

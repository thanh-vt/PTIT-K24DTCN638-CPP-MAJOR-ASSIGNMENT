#ifndef B_13_H
#define B_13_H

void print_matrix_borders(const std::vector<std::vector<int> > &A);

#endif //B_13_H

#ifndef B_26_H
#define B_26_H
#include <vector>

int min_merges_to_make_palindrome(std::vector<int>& arr);

#endif //B_26_H

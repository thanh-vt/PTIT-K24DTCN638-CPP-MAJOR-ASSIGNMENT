#ifndef B_06_H
#define B_06_H

/**
 * Kiểm tra số nguyên tố
 *
 * @param n số nguyên dương đầu vào
 * @return n có phải số nguyên tố hay không
 */
bool is_prime(int n);

#endif //B_06_H

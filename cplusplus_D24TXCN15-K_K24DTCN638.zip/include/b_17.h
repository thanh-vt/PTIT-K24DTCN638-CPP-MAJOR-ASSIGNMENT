#ifndef B_17_H
#define B_17_H
#include <string>

int count_substring_begin_end_equals(const std::string &S);

#endif //B_17_H

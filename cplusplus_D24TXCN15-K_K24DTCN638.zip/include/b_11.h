#ifndef B_11_H
#define B_11_H

std::vector<int> rotate_vector(const std::vector<int>& A, int d);

#endif //B_11_H

#ifndef B_01_H
#define B_01_H

/**
 * Tính tổng từ 1 đến n
 *
 * @param n Số nguyên dương đầu vào
 * @return Tổng từ 1 đến n
 */
int sum_1_to_n(int n);

#endif //B_01_H

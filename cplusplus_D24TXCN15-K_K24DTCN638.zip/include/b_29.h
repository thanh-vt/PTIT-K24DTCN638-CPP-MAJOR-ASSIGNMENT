#ifndef B_29_H
#define B_29_H
#include <string>

int sum_of_numbers(const std::string &S);

#endif //B_29_H

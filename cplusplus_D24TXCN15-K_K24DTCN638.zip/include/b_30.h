#ifndef B_30_H
#define B_30_H

std::string separate_alphabet_and_numeric(const std::string &S);

#endif //B_30_H

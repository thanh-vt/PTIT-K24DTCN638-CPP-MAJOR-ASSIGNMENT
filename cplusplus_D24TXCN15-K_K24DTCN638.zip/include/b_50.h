#ifndef B_50_H
#define B_50_H

std::set<std::string> collect_words_from_file(std::ifstream &inFile);

#endif //B_50_H

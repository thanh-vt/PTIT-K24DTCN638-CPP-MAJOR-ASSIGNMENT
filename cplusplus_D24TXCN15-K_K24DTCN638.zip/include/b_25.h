#ifndef B_25_H
#define B_25_H
#include <vector>

void rotate_matrix(std::vector<std::vector<int>>& mat, int n, int m);

#endif //B_25_H

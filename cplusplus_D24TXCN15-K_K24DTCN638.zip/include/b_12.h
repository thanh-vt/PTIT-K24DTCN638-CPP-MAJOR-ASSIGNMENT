#ifndef B_12_H
#define B_12_H

void print_modified_matrix(std::vector<std::vector<int>> A, int n, int m);

#endif //B_12_H

#ifndef B_27_H
#define B_27_H
#include <vector>

std::vector<std::vector<int>> print_convolution_matrix(const std::vector<std::vector<int>> &A, const std::vector<std::vector<int>> &B);

#endif //B_27_H

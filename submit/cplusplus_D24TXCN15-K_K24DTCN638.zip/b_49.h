#ifndef B_49_H
#define B_49_H

std::string to_lower(const std::string& s);

#endif //B_49_H

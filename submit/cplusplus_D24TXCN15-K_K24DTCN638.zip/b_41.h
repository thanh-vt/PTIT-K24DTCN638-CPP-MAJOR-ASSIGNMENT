#ifndef B_41_H
#define B_41_H

enum Gender {
    MALE,
    FEMALE
};

class exit_code_exception : public std::exception {
    int code;
    std::string message;
public:
    explicit exit_code_exception(const int c, std::string m) : code(c), message(std::move(m)) {}
    int getCode() const { return code; }
    const char* what() const noexcept override { return message.c_str(); }
};

int parse_int(const std::string &line);

std::string trim_and_validate_name(const std::string &input, int max_length);

Gender parse_gender(const std::string &line);

std::tm parse_date(const std::string &line);

std::string validate_tax_code(const std::string &line);

std::string print_gender(Gender gender);

std::string print_date(const std::tm &date);

class Employee {
public:
    Employee(std::string fullname, Gender gender, const std::tm &date_of_birth, std::string address,
             std::string tax_code, const std::tm &contract_sign_date);

    friend std::ostream &operator<<(std::ostream &os, const Employee &employee);
private:
    static int counter;
    std::string code;
    std::string fullname;
    Gender gender;
    std::tm dateOfBirth;
    std::string address;
    std::string taxCode;
    std::tm contractSignDate;
};


int Employee::counter = 0;

#endif //B_41_H
